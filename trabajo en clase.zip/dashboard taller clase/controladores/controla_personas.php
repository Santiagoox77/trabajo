<?php
$cantidad = $_POST["cant"];
$total = $cantidad * 2500;
if($cantidad >0 and $total>0)
{
    echo "el valor de tu compra es: ".$total;
}else{
    echo "no tiene ninguna compra o la compra es negativa";
}
?>