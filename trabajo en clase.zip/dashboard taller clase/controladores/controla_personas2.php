<?php
$valorgastado = $_POST["cant"];
$descripcion = $_POST["des"];

if($valorgastado >0 and $valorgastado <= 100000)
{
    echo "el valor gastado es: ".$valorgastado;
    echo "<br> descricion: ".$descripcion;
}else{
    echo "la compra es negativa ";
}
?>